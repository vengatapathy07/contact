<?php
echo phpinfo();
 ?>
