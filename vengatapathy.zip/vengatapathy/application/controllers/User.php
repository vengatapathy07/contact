<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('muser');
    }


    public function index()
    {
        $this->load->view('user/home');
    }

    public function successfully()
    {
        $this->load->view('user/successfully');
    }




    public function listcontact()
    {
        $this->muser->listcontact();
    }








}
