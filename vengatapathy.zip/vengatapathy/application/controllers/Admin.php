<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('mcrud');
    }


    public function index()
    {
        $this->load->view('admin/login');
    }


    public function view_admin()
    {
        $ltype = $this->session->userdata('ltype');

        if ($ltype == 'ADMINISTRATOR') {
            $this->load->view('admin/view_admin');
        } else {
            redirect('admin/index/ln');
        }

    }

    public function view_contact()
    {

        $ltype = $this->session->userdata('ltype');

        if ($ltype == 'ADMINISTRATOR') {
            $this->load->view('admin/view_contact');
        } else {
            redirect('admin/index/ln');
        }

    }

    public function sign_up()
    {

        $ltype = $this->session->userdata('ltype');

        if ($ltype == 'ADMINISTRATOR') {
            $this->load->view('admin/sign_up');
        } else {
            redirect('admin/index/ln');
        }

    }

    // mcrud


    public function addadmin()
    {
        $this->mcrud->addadmin();
    }

    public function login()
    {
        $this->mcrud->login();
    }


    public function view()
 	 {
 	 	$this->load->view('admin/view');
 	 }

   public function edit()
	{
		$this->load->view('admin/edit');
	}

  public function delete()
 {
	  $this->mcrud->delete();
	}

  public function updatecontact()
{
   $this->mcrud->updatecontact();
 }



    //Session Destroy Or Logout

    public function logout()
    {
        $this->session->unset_userdata('adminid');
        $this->session->unset_userdata('ltype');
        $this->session->unset_userdata('name');
        session_destroy();
        redirect('admin/index/lo');
    }






}
