<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Muser extends CI_Model
{


    public function listcontact()
    {
        $contactid   = 'C' . uniqid();
        $name        = $this->input->post('name');
        $email       = $this->input->post('email');
        $dob         = $this->input->post('dob');
        $gender = $this->input->post('gender');
        $address = $this->input->post('address');
        $tamil = $this->input->post('tamil');
        $malayalam = $this->input->post('malayalam');
        $english = $this->input->post('english');


        $data = array(
            'contactid' => $contactid,
            'name' => $name,
            'email' => $email,
            'dob' => $dob,
            'address' => $address,
            'gender' => $gender,
            'tamil' => $tamil ? $tamil : 0,
            'malayalam' => $malayalam ? $malayalam : 0,
            'english' => $english ? $english : 0,

            'status' => 1

        );

        $this->db->insert('contact', $data);

        if ($this->db->affected_rows() > 0) {
            redirect('user/successfully/msg_s');
        } else {
            redirect('user/successfully/msg_f');
        }

    }








}
