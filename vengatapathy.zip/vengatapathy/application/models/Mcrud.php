<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mcrud extends CI_Model
{


    public function listviewcontact()
    {
        $this->db->select('*');
        $this->db->from('contact')->order_by("id", "desc");
        $query = $this->db->get();
        return $query->result();


    }



    public function addadmin()
    {
        $email    = $this->input->post('email');
        $name     = $this->input->post('name');
        $password = MD5($this->input->post('password'));
        $adminid  = 'C' . uniqid();
        $ltype ='ADMINISTRATOR';

        $data = array(
            'adminid' => $adminid,
            'name' => $name,
            'email' => $email,
            'password' => $password,
            'ltype' => $ltype,
            'status' => 1
        );

        $this->db->insert('sign_up', $data);

        if ($this->db->affected_rows() > 0) {
            redirect('admin/view_admin/msg_s');
        } else {
            redirect('admin/view_admin/msg_f');
        }

    }


    public function login()
    {
        $name     = $this->input->post('name');
        $password = MD5($this->input->post('password'));

        $this->db->select('*');
        $this->db->from('sign_up');
        $this->db->where('name', $name);
        $this->db->where('password', $password);
        $query = $this->db->get();
        $row   = $query->num_rows();

        if ($row > 0) {
            foreach ($query->result() as $rowArray) {
                $name      = $rowArray->name;
                $adminid   = $rowArray->adminid;
                $email     = $rowArray->email;
                $password = $rowArray->password;
                $ltype     = $rowArray->ltype;


            }

            /*
            print_r("<pre>");
            print_r($rowArray);
            print_r("</pre>");
            */

            $this->session->set_userdata('name', $name);
            $this->session->set_userdata('adminid', $adminid);
            $this->session->set_userdata('email', $email);
            $this->session->set_userdata('password', $password);
            $this->session->set_userdata('ltype', $ltype);


            redirect('admin/view_contact/ln');
        }

        else {
            redirect('admin/index/lf');
        }

    }





    public function listadmin()
    {
        $this->db->select('*');
        $this->db->from('sign_up')->order_by("id", "asc");
        $query = $this->db->get();
        return $query->result();


    }



    public function delete() {

$contactid = $this->input->post('id');

   $this->db->where('contactid',$contactid);
   $this->db->delete('contact');

   if ($this->db->affected_rows() == '1') {
  	 redirect('admin/view_contact/msg_d');
   } else {
  	 redirect('admin/view_contact/msg_f');
   }
  }


  public function listcontact($contactid) {
  	 $this->db->select('*');
  	 $this->db->from('contact');
  	 $this->db->where('contactid', $contactid );
  	 $query = $this->db->get();
  	 return $query->result();


  }



  public function listcontactedit($contactid) {
  	 $this->db->select('*');
  	 $this->db->from('contact');
  	 $this->db->where('contactid', $contactid );
  	 $query = $this->db->get();
  	 return $query->result();


  }





  public function updatecontact()
  {
    $contactid = $this->input->post('contactid');
    $name        = $this->input->post('name');
    $email       = $this->input->post('email');
    $dob         = $this->input->post('dob');
    $gender = $this->input->post('gender');
    $address = $this->input->post('address');
    $tamil = $this->input->post('tamil');
    $malayalam = $this->input->post('malayalam');
    $english = $this->input->post('english');


    $data = array(
        'name' => $name,
        'email' => $email,
        'dob' => $dob,
        'address' => $address,
        'gender' => $gender,
        'tamil' => $tamil,
        'malayalam' => $malayalam,
        'english' => $english

    );
  			$this->db->where('contactid', $contactid );
  	    $this->db->update('contact',$data);

  			if ($this->db->affected_rows() == '1') {
  				redirect('admin/view_contact/msg_e');
  			} else {
  				redirect('admin/view_contact/msg_f');
  			}
  		}

















}
