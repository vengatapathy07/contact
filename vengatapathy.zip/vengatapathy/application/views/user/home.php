<?php
   defined('BASEPATH') OR exit('No direct script access allowed');
   ?><!DOCTYPE html>
<html lang="en">
   <head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">



<!--Validation-->
      <link rel="stylesheet" href="http://conceptegrafic.com/jcuacc/formValidatorv22/css/validationEngine.jquery.css" type="text/css"/>
      <link rel="stylesheet" href="http://conceptegrafic.com/jcuacc/formValidatorv22/css/template.css" type="text/css"/>

      <!-- END Validatiuon engine-->



   </head>
   <body>
      <header class="navbar navbar-header navbar-header-fixed">
         <div class="navbar-brand">
            <a href="<?php echo site_url('user/index'); ?>" class="df-logo">Contact</a>
         </div>
         <!-- navbar-brand -->
         <div class="navbar-right">
            <a href="<?php echo site_url('admin/index'); ?>" class="btn btn-primary"> <span>Admin Login</span></a>
         </div>
         <!-- navbar-right -->
      </header>
      <div class="container ">
         <form id="formID" class="ml-5" action="<?php echo site_url('user/listcontact'); ?>" method="post" name="google-sheet">
            <h2 class="text-secondary mt-5 mb-3">Contact Form
            </h2>
            <div class="row">
               <div class="col-md-5 mb-3">
                  <label for="exampleInputEmail1">Name :</label>
                  <input type="text" name="name" placeholder=""  class=" vali_name validate[required] form-control form-control-lg" id="name"/>
               </div>
               <div class="col-md-5 mb-3">
                  <label for="exampleInputEmail1">Email ID :</label>
                  <input id="email" type="email" name="email" class="form-control vali_email validate[required,custom[email]] text-input" style="width:100%; height:auto;" aria-describedby="emailHelp" >
               </div>
               <div class="col-md-5 mb-3">
                  <label for="exampleInputEmail1">DOB :</label>
                  <input id="dob" type="date" name="dob" class="form-control vali_dob validate[required]" aria-describedby="emailHelp" max="" required>
               </div>

               <script>

                var currentDate = new Date();
                currentDate.setFullYear(currentDate.getFullYear() - 18);
                var minDate = currentDate.toISOString().split('T')[0];
                document.getElementById("dob").setAttribute("max", minDate);
               </script>

   <div class="col-md-5 mb-3">
                 <label for='Color'>Gender :</label>
               <label><input type='radio'class="text-input" name='gender' value='male' />Male</label>
               <label><input type='radio'class="text-input" name='gender' value='female' />Female</label>
                 </div>

               <div class="col-md-12 mb-3">
                  <label for="exampleInputPassword1">Address :</label><br>
                  <textarea id="msg" class="vali_msg validate[required] text-input"  name="address" rows="8" cols="117" ></textarea>
               </div>
                   <style>
                       .option-container {
                           display: flex;
                           flex-direction: column;
                       }
                       .option {
                           margin-bottom: 10px;
                       }
                   </style>
                   <div class="option-container">
                     <label for="exampleInputEmail1">Language :</label>
                       <label class="option">
                           <input type="checkbox" name="tamil" value="1"> Tamil
                       </label>
                       <label class="option">
                           <input type="checkbox" name="malayalam" value="1"> Malayalam
                       </label>
                       <label class="option">
                           <input type="checkbox" name="english" value="1"> English
                       </label>
                   </div>
            </div>
            <button type="submit" class="btn btn-primary btn-lg">Submit</button>
         </form>
      </div>






      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


      <!-- Validation-->

      <script src="http://conceptegrafic.com/jcuacc/formValidatorv22/js/jquery-1.6.min.js" type="text/javascript">
      </script>
      <script src="http://conceptegrafic.com/jcuacc/formValidatorv22/js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8">
      </script>
      <script src="http://conceptegrafic.com/jcuacc/formValidatorv22/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8">
      </script>
      <script>
          jQuery(document).ready(function(){
              jQuery("#formID").validationEngine();
          });

       </script>
      <!-- END Validatiuon engine -->



   </body>
</html>
