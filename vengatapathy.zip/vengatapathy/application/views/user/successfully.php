<?php
   defined('BASEPATH') OR exit('No direct script access allowed');
   ?><!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
      <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
      <!--Validation-->
      <link rel="stylesheet" href="http://conceptegrafic.com/jcuacc/formValidatorv22/css/validationEngine.jquery.css" type="text/css"/>
      <link rel="stylesheet" href="http://conceptegrafic.com/jcuacc/formValidatorv22/css/template.css" type="text/css"/>
      <!-- END Validatiuon engine-->
      <style>
         .modal-confirm {
         color: #636363;
         width: 500px;
         font-size: 14px;
         }
         .modal-confirm .modal-content {
         padding: 20px;
         border-radius: 5px;
         }
         .modal-confirm .modal-header {
         border-bottom: none;
         position: relative;
         }
         .modal-confirm h4 {
         text-align: center;
         font-size: 26px;
         margin: 30px 0 -15px;
         }
         .modal-confirm .form-control, .modal-confirm .btn {
         min-height: 40px;
         border-radius: 3px;
         }
         .modal-confirm .close {
         position: absolute;
         top: -5px;
         right: -5px;
         }
         .modal-confirm .modal-footer {
         border: none;
         text-align: center;
         border-radius: 5px;
         font-size: 13px;
         }
         .modal-confirm .icon-box {
         color: #fff;
         position: absolute;
         margin: 0 auto;
         left: 0;
         right: 0;
         top: -70px;
         width: 95px;
         height: 95px;
         border-radius: 50%;
         z-index: 9;
         background: #82CE34;
         padding: 15px;
         text-align: center;
         box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1);
         }
         .modal-confirm .icon-box i {
         font-size: 58px;
         position: relative;
         top: 3px;
         }
         .modal-confirm.modal-dialog {
         margin-top: 80px;
         }
         .modal-confirm .icon-boxred {
         color: #fff;
         position: absolute;
         margin: 0 auto;
         left: 0;
         right: 0;
         top: -70px;
         width: 95px;
         height: 95px;
         border-radius: 50%;
         z-index: 9;
         background: #dc3545;
         padding: 15px;
         text-align: center;
         box-shadow: 0px 2px 2px rgb(0 0 0 / 10%);
         }
         .xfount{font-size: 50px !important;}
      </style>
   </head>
   <body>
      <header class="navbar navbar-header navbar-header-fixed">
         <div class="navbar-brand">
            <a href="<?php echo site_url('user/index'); ?>" class="df-logo">Contact</a>
         </div>
         <!-- navbar-brand -->
         <div class="navbar-right">
            <a href="<?php echo site_url('admin/index'); ?>" class="btn btn-primary"> <span>Admin Login</span></a>
         </div>
         <!-- navbar-right -->
      </header>
      <div class="container ">
         <?php
            $uri3 = $this->uri->segment(3);
            if($uri3=='msg_s') {
              ?>
         <div class="modal-dialog modal-confirm">
            <div class="modal-content">
               <div class="modal-header">
                  <div class="icon-box">
                     <i class="material-icons">&#xE876;</i>
                  </div>
                  <h4 class="modal-title w-100">Thank You</h4>
               </div>
               <div class="modal-body">
                  <p class="text-center">Form was submitted Successfully</p>
               </div>
               <div class="modal-footer">
                  <a href="<?php echo site_url('user/index'); ?>" class="btn btn-success btn-block" data-dismiss="modal">Back to contact form</a>
               </div>
            </div>
         </div>
         <?php
            }
            elseif($uri3=='msg_f') {
            ?>
         <div class="modal-dialog modal-confirm">
            <div class="modal-content">
               <div class="modal-header">
                  <div class="icon-boxred">
                     <i class="material-icons xfount">X</i>
                  </div>
                  <h4 class="modal-title w-100">Sorry</h4>
               </div>
               <div class="modal-body">
                  <p class="text-center">Form was not submitted</p>
               </div>
               <div class="modal-footer">
                  <a href="<?php echo site_url('user/index'); ?>" class="btn btn-success btn-block" data-dismiss="modal">Back to contact form</a>
               </div>
            </div>
         </div>
         <?php } ?>
      </div>
      <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
      <!-- Validation-->
      <script src="http://conceptegrafic.com/jcuacc/formValidatorv22/js/jquery-1.6.min.js" type="text/javascript"></script>
      <script src="http://conceptegrafic.com/jcuacc/formValidatorv22/js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script>
      <script src="http://conceptegrafic.com/jcuacc/formValidatorv22/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
      <script>
         jQuery(document).ready(function(){
         		// binds form submission and fields to the validation engine
         		jQuery("#formID").validationEngine();
         });

      </script>
      <!-- END Validatiuon engine -->
      <script></script>
   </body>
</html>
