<?php
   defined('BASEPATH') OR exit('No direct script access allowed');
   ?><!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
      <link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/assets/css/style.css">
      <style>
         th {
         cursor: pointer;
         }
      </style>
   </head>
   <body>
      <div class="wrapper">
         <!-- Sidebar  -->
         <nav id="sidebar">
            <div class="sidebar-header">
               <h3>Admin</h3>
            </div>
            <ul class="list-unstyled components">
               <li>
                  <a href="<?php echo site_url('admin/view_contact'); ?>">View Contact</a>
               </li>
               <li>
                  <a href="<?php echo site_url('admin/view_admin'); ?>">Admin Account</a>
               </li>
               <li>
                  <a href="<?php echo site_url('admin/sign_up'); ?>">Add Admin</a>
               </li>
            </ul>
         </nav>
         <!-- Page Content  -->
         <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
               <div class="container-fluid">
                  <button type="button" id="sidebarCollapse" class="btn">
                  <i class="fas fa-align-left"></i>
                  <span><img src="<?php echo base_url(); ?>assets/admin/assets/img/icons8-menu.gif" </span>
                  </button>
                  <ul class="list-unstyled components">
                     <li>
                        <a  href="<?php echo site_url('admin/logout'); ?>">Logout</a>
                     </li>
                  </ul>
               </div>
            </nav>
            <div class="container">
               <div class="row">
                  <div class="col-md-12">
                     <h2>Contact List</h2>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <div class="widget blank no-padding">
                        <div class="panel panel-default work-progress-table">
                           <!-- Table -->
                           <table id="mytable" class="table">
                              <thead>
                                 <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Action</th>
                                 </tr>
                              </thead>
                              <tbody>
                                 <?php
                                    $listviewcontact = $this->mcrud->listviewcontact();
                                    $i=1;
                                    foreach($listviewcontact as $listviewcontactArray) {
                                    	$contactid = $listviewcontactArray->contactid;
                                    ?>
                                 <tr>
                                    <td scope="row"><?php echo $i; ?></td>
                                    <td><?php echo $listviewcontactArray->name; ?></td>
                                    <td><?php echo $listviewcontactArray->email; ?></td>
                                    <td>
						 					<a class="btn btn-sm btn-primary" href="<?php echo site_url('admin/view/'.$contactid.''); ?>" role="button">View</a>
						 					<a class="btn btn-sm btn-warning" href="<?php echo site_url('admin/edit/'.$contactid.''); ?>" role="button">Edit</a>
						 					<!-- <a class="btn btn-sm btn-danger" href="<?php// echo site_url('admin/delete/'.$contactid.''); ?>" role="button">Delete</a> -->

<button type="button" class="btn btn-sm btn-danger" data-id="<?php echo $listviewcontactArray->contactid; ?>" onclick="confirmDelete(this);">Delete</button>

<div id="myModal" class="modal">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h4 class="modal-title">Delete User</h4>
                <button type="button" class="close" data-dismiss="modal">×</button>
            </div>

            <div class="modal-body">
                <p>Are you sure you want to delete this user ?</p>
                <form method="POST" action="<?php echo site_url('admin/delete'); ?>" id="form-delete-user">
                    <input type="hidden" name="id">
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" form="form-delete-user" class="btn btn-danger">Delete</button>
            </div>

        </div>
    </div>
</div>
<script>
function confirmDelete(self) {
    var id = self.getAttribute("data-id");

    document.getElementById("form-delete-user").id.value = id;
    $("#myModal").modal("show");
}

</script>

						 				</td>
                                 </tr>
                              </tbody>
                              <?php  $i++; } ?>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>

      <script>
         $(document).ready(function () {
                     $('#sidebarCollapse').on('click', function () {
                         $('#sidebar').toggleClass('active');
                     });
                 });
      </script>
      <script>
         $('th').click(function(){
             var table = $(this).parents('table').eq(0)
             var rows = table.find('tr:gt(0)').toArray().sort(comparer($(this).index()))
             this.asc = !this.asc
             if (!this.asc){rows = rows.reverse()}
             for (var i = 0; i < rows.length; i++){table.append(rows[i])}
         })
         function comparer(index) {
             return function(a, b) {
                 var valA = getCellValue(a, index), valB = getCellValue(b, index)
                 return $.isNumeric(valA) && $.isNumeric(valB) ? valA - valB : valA.toString().localeCompare(valB)
             }
         }
         function getCellValue(row, index){ return $(row).children('td').eq(index).text() }

      </script>
   </body>
</html>
