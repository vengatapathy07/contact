<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to Codeigniter</title>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

</head>
<body>


<div class="row">
	<div class="container">


		<p>&nbsp;</p>

		<p>&nbsp;</p>


	 	<p>&nbsp;</p>

  <?php
  $uri3 = $this->uri->segment(3);
   $listcontactedit = $this->mcrud->listcontactedit($uri3);
  $i=1;
  foreach($listcontactedit as $listcontacteditArray) {
    $contactid = $listcontacteditArray->contactid;
  ?>


  <form action="<?php echo site_url('admin/updatecontact'); ?>" method="post">
  <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title" id="exampleModalLabel">Edit Student</h5>
      <a href="<?php echo site_url('admin/view_contact'); ?>" type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </a>
    </div>
    <div class="modal-body">


        <div class="row">
          <div class="col-sm-3">
            <div class="form-group">
              <label for="exampleInputEmail1">Name</label>
              <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
               name="name" placeholder=" " value="<?php echo $listcontacteditArray->name; ?>">
            </div>
          </div>

          <div class="col-sm-9">
            <div class="form-group">
              <label for="exampleInputPassword1">Email</label>
              <input type="text" class="form-control" name="email" id="exampleInputPassword1" placeholder=""  value="<?php echo $listcontacteditArray->email; ?>">
            </div>
          </div>
        </div>



        <div class="form-group">
         <label for="exampleInputPassword1">DOB</label>
         <input type="date" class="form-control" name="dob" id="exampleInputPassword1" placeholder="" value="<?php echo $listcontacteditArray->dob; ?>">
       </div>

       <div class="form-group">
         <label for="exampleInputPassword1">Gender</label>
         <input type="text" class="form-control" id="exampleInputPassword1" name='gender' placeholder="" value="<?php echo $listcontacteditArray->gender; ?>" disabled>
       <label><input type='radio'class="validate[required,custom[gender]] text-input" name='gender' value='male' />Male</label>
       <label><input type='radio'class="validate[required,custom[gender]] text-input" name='gender' value='female' />Female</label>
       </div>

       <div class="form-group">
         <label for="exampleInputPassword1">Address</label>
         <textarea class="form-control" id="exampleInputPassword1" name="address" rows="8" cols="117"><?php echo $listcontacteditArray->address; ?></textarea>
       </div>







<label for="exampleInputPassword1">Language:</label>
				 <?php
$tamil = $listcontacteditArray->tamil;
?>

<input type="checkbox" id="tamilCheckbox" name="tamil" value="<?php echo $tamil; ?>" <?php echo ($tamil == 1) ? 'checked' : ''; ?>> Tamil

<script>
document.getElementById('tamilCheckbox').addEventListener('change', function() {
this.value = (this.value === '1') ? '0' : '1';
});
</script>

<?php
$malayalam = $listcontacteditArray->malayalam;
?>

<input type="checkbox" id="malayalamCheckbox" name="malayalam" value="<?php echo $malayalam; ?>" <?php echo ($malayalam == 1) ? 'checked' : ''; ?>> Malayalam

<script>
document.getElementById('malayalamCheckbox').addEventListener('change', function() {
this.value = (this.value === '1') ? '0' : '1';
});
</script>

<?php
$english = $listcontacteditArray->english;
?>

<input type="checkbox" id="englishCheckbox" name="english" value="<?php echo $english; ?>" <?php echo ($english == 1) ? 'checked' : ''; ?>> English

<script>
document.getElementById('englishCheckbox').addEventListener('change', function() {
this.value = (this.value === '1') ? '0' : '1';
});
</script>




    </div>
    <div class="modal-footer">
      <a href="<?php echo site_url('admin/view_contact'); ?>" class="btn btn-primary pull-right">Back</a>

      <input type="hidden" name="contactid" value="<?php echo $listcontacteditArray->contactid; ?>" />
      <button type="submit" class="btn btn-primary">Update</button>
    </div>
  </div>

  </form>

<?php } ?>
</div>
</div>


<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
</body>
</html>
