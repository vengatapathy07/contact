<?php
   defined('BASEPATH') OR exit('No direct script access allowed');
   ?><!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
      <!--Validation-->
      <link rel="stylesheet" href="http://conceptegrafic.com/jcuacc/formValidatorv22/css/validationEngine.jquery.css" type="text/css"/>
      <link rel="stylesheet" href="http://conceptegrafic.com/jcuacc/formValidatorv22/css/template.css" type="text/css"/>
      <!-- END Validatiuon engine-->
   </head>
   <body>
      <div class="container ">
         <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
               <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                  <div class="card bg-dark text-white" style="border-radius: 1rem;">
                     <div class="card-body p-5 text-center">
                        <div class="mb-md-5 mt-md-4 pb-5">
                           <h2 class="fw-bold mb-2 text-uppercase">Login</h2>
                           <p class="text-white-50 mb-5">Please enter your Username and password!</p>
                           <form id="formID" action="<?php echo site_url('admin/login'); ?>" method="post">
                              <div class="form-outline form-white mb-4">
                                 <label class="form-label" for="typeEmailX">Username</label>
                                 <input type="text" id="typeEmailX" name="name" class="form-control form-control-lg validate[required,custom[onlyLetterSp]] text-input" />
                              </div>
                              <div class="form-outline form-white mb-4">
                                 <label class="form-label" for="typePasswordX">Password</label>
                                 <input type="password" id="typePasswordX" name="password" class="form-control form-control-lg validate[required] text-input" />
                              </div>
                              <button  class="btn btn-outline-light btn-lg px-5" type="submit">Login</button>
                           </form>
                        </div>
                        <div>
                           <p  class="mb-0"><a href="<?php echo site_url('user/index'); ?>" class="text-white-50 fw-bold">Back to Contact form</a>
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
      <!-- Validation-->
      <script src="http://conceptegrafic.com/jcuacc/formValidatorv22/js/jquery-1.6.min.js" type="text/javascript"></script>
      <script src="http://conceptegrafic.com/jcuacc/formValidatorv22/js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script>
      <script src="http://conceptegrafic.com/jcuacc/formValidatorv22/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
      <script>
         jQuery(document).ready(function(){
         		// binds form submission and fields to the validation engine
         		jQuery("#formID").validationEngine();
         });

      </script>
      <!-- END Validatiuon engine -->
   </body>
</html>
